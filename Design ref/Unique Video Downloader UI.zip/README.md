
  # Unique Video Downloader UI

  This is a code bundle for Unique Video Downloader UI. The original project is available at https://www.figma.com/design/DPkjP2o0omh0zVNAbm8tYj/Unique-Video-Downloader-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  